#include <stdio.h>
#include <xparameters.h>
#include "xaxidma.h"
#include "img_in.h"

#include <time.h>
#include <stdio.h>
#include <stdlib.h>

//XFilter doFilter;
//XFilter_Config *doFilter_cfg;
XAxiDma axiDMA;
XAxiDma_Config *axiDMA_cfg;

#define MEM_BASE_ADDR 0x01000000
#define TX_BUFFER_BASE (MEM_BASE_ADDR+0x00100000)
#define RX_BUFFER_BASE (MEM_BASE_ADDR+0x00300000)

#define SIZE_ARR (640*480)
unsigned char inStreamData[SIZE_ARR];
unsigned char outStreamData[SIZE_ARR];

void initPeripherals() {


	printf("initializing AxiDMA\n");
	axiDMA_cfg = XAxiDma_LookupConfig(XPAR_AXIDMA_0_DEVICE_ID);
	if (axiDMA_cfg) {
		int status = XAxiDma_CfgInitialize(&axiDMA, axiDMA_cfg);
		if (status != XST_SUCCESS)
			printf("Error initializing AxiDMA core\n");
	}

	XAxiDma_IntrDisable(&axiDMA, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DEVICE_TO_DMA);
	XAxiDma_IntrDisable(&axiDMA, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DMA_TO_DEVICE);
}

int main() {

	unsigned char *m_dma_buffer_TX = (unsigned char*) TX_BUFFER_BASE;
	unsigned char *m_dma_buffer_RX = (unsigned char*) RX_BUFFER_BASE;

	initPeripherals();
	clock_t start, end;

	unsigned char teller = 0x00;
	for (int idx = 0; idx < SIZE_ARR; idx++) {
		if ( (idx > 305700) && (idx < 305703) ){
			teller = 0xFF;//rand() % 255;
			}
		else teller = 0x00;
		inStreamData[idx] = teller;
		//teller++;
		//if (teller > 0xFF) teller = 0x00;
	}

	for (int idv = 305500; idv < 305503; idv++) {
			teller = 0xFF;//rand() % 255;
			inStreamData[idv] = teller;
	}
	for (int idv = 305300; idv < 305303; idv++) {
			teller = 0xFF;//rand() % 255;
			inStreamData[idv] = teller;
	}

	for (int idc = 306400; idc < 307000; idc++) {
			teller = 0xFF;//rand() % 255;
			inStreamData[idc] = teller;
	}


	//Xil_ICacheDisable();
	Xil_DCacheDisable();

	while (1) {

		start = clock();
		Xil_DCacheFlushRange((u32) inStreamData, SIZE_ARR * sizeof(unsigned char));
		Xil_DCacheFlushRange((u32) m_dma_buffer_RX, SIZE_ARR * sizeof(unsigned char));

		printf("Sending data to IP core slave\n");
		XAxiDma_SimpleTransfer(&axiDMA, (u32) inStreamData, SIZE_ARR * sizeof(unsigned char), XAXIDMA_DMA_TO_DEVICE);
		printf("Receive data from IP core\n");
		XAxiDma_SimpleTransfer(&axiDMA, (u32) m_dma_buffer_RX, SIZE_ARR * sizeof(unsigned char), XAXIDMA_DEVICE_TO_DMA);

		while (XAxiDma_Busy(&axiDMA, XAXIDMA_DMA_TO_DEVICE));
		while (XAxiDma_Busy(&axiDMA, XAXIDMA_DEVICE_TO_DMA));

		Xil_DCacheInvalidateRange((u32) m_dma_buffer_RX, SIZE_ARR * sizeof(unsigned char));

		start = clock() - start;
		printf("Calculation complete\n");
		double time_taken = ((double)start) / (CLOCKS_PER_SEC);
		printf("Time taken by program is : %f\n", time_taken);

		for (int idx = 0; idx < SIZE_ARR; idx++) {
			if (outStreamData[idx] != 0)
				{
				  teller++;
				}
		}

	}

	return 0;
}
